from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, user, password, host='localhost', port=27017, db='aac', col='animals'):
        # MongoDB connection URI with proper authSource
        uri = f"mongodb://{user}:{password}@{host}:{port}/{db}?authSource={db}"
        self.client = MongoClient(uri)
        self.database = self.client[db]
        self.collection = self.database[col]

    def create(self, data):
        if not data or not isinstance(data, dict):
            print("No data provided to insert.")
            return False
        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except Exception as e:
            print("Error inserting document:", e)
            return False

    def read(self, query=None):
        if query is None:
            query = {}
        try:
            cursor = self.collection.find(query, {"_id": False})
            return list(cursor)
        except Exception as e:
            print("Read error:", e)
            return []

    def aggregate(self, pipeline):
        """
        Run a MongoDB aggregation pipeline on the animals collection.
        Expects 'pipeline' to be a list of aggregation stages (dicts).
        Returns a list of result documents.
        """
        try:
            cursor = self.collection.aggregate(pipeline)
            return list(cursor)
        except Exception as e:
            print("Aggregate error:", e)
            return []

    def update(self, query, new_values, many=False):
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            print("Invalid query or update data.")
            return 0
        try:
            if many:
                result = self.collection.update_many(query, new_values)
            else:
                result = self.collection.update_one(query, new_values)
            return result.modified_count
        except Exception as e:
            print("Update error:", e)
            return 0

    def delete(self, query, many=False):
        if not isinstance(query, dict):
            print("Invalid query data.")
            return 0
        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return result.deleted_count
        except Exception as e:
            print("Delete error:", e)
            return 0