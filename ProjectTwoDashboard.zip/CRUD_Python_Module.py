from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, user, password, host='localhost', port=27017, db='aac', col='animals'):
        # Set connection credentials and database/collection names
        # Create MongoDB client and select database/collection
        #USER = 'aacuser'
        #PASS = 'password'
        #HOST = 'localhost'
        #PORT = 27017
        #DB = 'aac'
        #COL = 'animals'
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (user, password, host, port))
        self.database = self.client[db]
        self.collection = self.database[col]

    def create(self, data):
        # Check that data is a non-empty dictionary before inserting
        if not data or not isinstance(data, dict):
            print("No data provided to insert.")
            return False

        try:
            # Insert one new document into the animals collection
            result = self.collection.insert_one(data)
            # Return True if MongoDB reports a new _id
            return True if result.inserted_id else False
        except Exception as e:
            # Print any error that occurs during insert
            print("Error inserting document:", e)
            return False

    def read(self, query=None):
        # Use empty query to return all documents if none is provided
        if query is None:
            query = {}

        try:
            # Use find() to get a cursor matching the query
            cursor = self.collection.find(query, {"_id": False})
            # Convert the cursor to a list of documents
            return list(cursor)
        except Exception as e:
            # Print any error that occurs during read
            print("Read error:", e)
            return []

    def update(self, query, new_values, many=False):
        # Ensure both query and update specs are dictionaries
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            print("Invalid query or update data.")
            return 0

        try:
            # Choose to update one document or many based on flag
            if many:
                result = self.collection.update_many(query, new_values)
            else:
                result = self.collection.update_one(query, new_values)
            # Return how many documents were actually modified
            return result.modified_count
        except Exception as e:
            # Print any error that occurs during update
            print("Update error:", e)
            return 0

    def delete(self, query, many=False):
        # Ensure query is a dictionary before deleting
        if not isinstance(query, dict):
            print("Invalid query data.")
            return 0

        try:
            # Choose to delete one document or many based on flag
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            # Return how many documents were deleted
            return result.deleted_count
        except Exception as e:
            # Print any error that occurs during delete
            print("Delete error:", e)
            return 0
