// ===========================================================================
// Project: Security Vulnerability Analysis and Fixes for Client Management C++ Program
// Author:  Tyler Bryant
// Date:    June 17, 2026
// ===========================================================================

#include <iostream>
#include <string>
#include <limits>

// Structure for client records
struct Client {
    int id;
    std::string name;
    int serviceChoice; // 1 = Brokerage, 2 = Retirement
};

// Global array holding the database records
Client g_Clients[5] = {
    {1, "Bob Jones", 1},
    {2, "Sarah Davis", 2},
    {3, "Amy Friendly", 1},
    {4, "Johnny Smith", 1},
    {5, "Carol Spears", 2}
};

int g_UserChoice = 0;
int g_CurrentPermissionLevel = 0;

// Function prototypes
int CheckUserPermissionAccess();
void DisplayInfo();
void ChangeCustomerChoice();

int main() {
    // SECURITY VULNERABILITY 1: Hard-coded credentials
    // Problem: Username/password are in the source code, so anyone can see them.
    // Fix: Use secure authentication outside the source code in real systems.

    // SECURITY VULNERABILITY 2: No account lockout or throttling
    // Problem: Unlimited login attempts allow brute-force attacks.
    // Fix: Add attempt limits and delays after failed logins.

    // SECURITY VULNERABILITY 3: Missing authorization for privileged actions
    // Problem: Any logged-in user can change client data.
    // Fix: Add role checks (e.g., only admins can modify records).

    // FIXED BUG: Input Stream Handling / Logic Bug
    // Original: std::cin >> g_UserChoice;
    // Problem: Non-integer input causes infinite loop.
    // Fix: Validate input, clear errors, and ignore bad data.
    bool authenticated = false;
    while (!authenticated) {
        g_CurrentPermissionLevel = CheckUserPermissionAccess();

        if (g_CurrentPermissionLevel == 1) {
            authenticated = true; // Pass screen
        }
        else {
            std::cout << "Invalid Password. Please try again\n";
        }
    }

    // Main Menu Loop
    do {
        std::cout << "\nWhat would you like to do?\n";
        std::cout << "DISPLAY the client list (enter 1)\n";
        std::cout << "CHANGE a client's choice (enter 2)\n";
        std::cout << "Exit the program.. (enter 3)\n";

        // FIX: If the user types a non-integer (like a letter), std::cin fails and enters an infinite loop.
        if (!(std::cin >> g_UserChoice)) {
            std::cout << "Invalid input. Please enter a number.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        std::cout << "You chose " << g_UserChoice << "\n";

        // Route to the correct function based on user input
        switch (g_UserChoice) {
        case 1:
            DisplayInfo();
            break;
        case 2:
            ChangeCustomerChoice(); // RECOMMENDED FIX: Add role check here
            break;
        case 3:
            break;
        default:
            std::cout << "Invalid option. Please choose 1, 2, or 3.\n";
            break;
        }

    } while (g_UserChoice != 3); // Exit if user types 3

    return 0;
}

// Function 1: Asks for username and password
int CheckUserPermissionAccess() {
    // FIXED BUG: Logic / Input Buffer Bug
    // Original: Only std::cin.clear();
    // Problem: clear() resets flags but doesn't remove buffered data.
    // Fix: Add std::cin.ignore() to discard leftover buffer data.

    std::string username = "";
    std::string password = "";

    std::cin.clear();
    // std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Uncomment if menu skips inputs

    std::cout << "Enter your username: ";
    if (!(std::cin >> username)) return 0;

    std::cout << "Enter your password: ";
    if (!(std::cin >> password)) return 0;

    // Direct string comparison matching the binary logic
    if (username == "name5" && password == "password") {
        return 1; // Admin Access Approved
    }

    return 0; // Explicitly fail access
}

// Function 2: Prints out the list of clients and their current selections
void DisplayInfo() {
    std::cout << "   Client's Name    Service Selected (1 = Brokerage, 2 = Retirement)\n";

    for (int i = 0; i < 5; ++i) {
        std::cout << g_Clients[i].id << ". " << g_Clients[i].name
            << " selected option " << g_Clients[i].serviceChoice << "\n";
    }
}

// Function 3: Modifies a specific client's choice value
void ChangeCustomerChoice() {
    // FIXED BUG: Input Validation Bug for client number
    // Original: std::cin >> targetClientNum;
    // Problem: Non-numeric input breaks the program.
    // Fix: Validate input, clear errors, and ignore bad data.

    int targetClientNum = 0;
    int updatedServiceChoice = 0;

    std::cout << "Enter the number of the client that you wish to change\n";

    if (!(std::cin >> targetClientNum)) {
        std::cout << "Invalid input. Returning to menu.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    int targetIndex = -1;

    // Find the correct client index matching the entered number
    if (targetClientNum == 1) targetIndex = 0;
    else if (targetClientNum == 2) targetIndex = 1;
    else if (targetClientNum == 3) targetIndex = 2;
    else if (targetClientNum == 4) targetIndex = 3;
    else if (targetClientNum == 5) targetIndex = 4;

    // If a valid client was found, update their choice
    if (targetIndex != -1) {
        std::cout << "Please enter the client's new service choice (1 = Brokerage, 2 = Retirement)\n";

        // FIXED BUG: Security / Logic Validation Bug for service choice
        // Original: std::cin >> updatedServiceChoice;
        // Problem: Invalid values could corrupt database state.
        // Fix: Only accept 1 or 2.

        if (std::cin >> updatedServiceChoice && (updatedServiceChoice == 1 || updatedServiceChoice == 2)) {
            g_Clients[targetIndex].serviceChoice = updatedServiceChoice;
            std::cout << "Choice successfully updated!\n";
        }
        else {
            std::cout << "Invalid service choice. Changes not saved.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
    else {
        std::cout << "Client lookup failure.\n";
    }
}

// SUMMARY OF FIXES:
// 1. Added input validation for menu choice using cin.clear() and cin.ignore().
// 2. Added input validation for client number.
// 3. Added validation for service choice (1 or 2 only).
// 4. Kept input buffer clear logic in CheckUserPermissionAccess().
//
// RECOMMENDED FIXES NOT IMPLEMENTED:
// 1. Remove hard-coded credentials and use secure authentication.
// 2. Add account lockout after failed login attempts.
// 3. Add login throttling (delays between attempts).
// 4. Implement role-based access control.
// 5. Protect global state with controlled access functions.